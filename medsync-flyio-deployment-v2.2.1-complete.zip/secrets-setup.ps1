# MEDsync EMS Suite - Secrets Configuration Script
# Securely configure production environment variables

param(
    [Parameter(Mandatory=$true)]
    [string]$AppName
)

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "MEDsync EMS Suite - Secrets Setup" -ForegroundColor Cyan
Write-Host "App: $AppName" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

# Verify app exists
try {
    flyctl apps show $AppName 2>$null
    Write-Host "✓ App '$AppName' found" -ForegroundColor Green
} catch {
    Write-Host "✗ App '$AppName' not found" -ForegroundColor Red
    exit 1
}

# Core required secrets
Write-Host "`n--- Required Configuration ---" -ForegroundColor Yellow

$resgridUser = Read-Host "Resgrid Username"
$resgridPass = Read-Host "Resgrid Password" -AsSecureString
$resgridPassPlain = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($resgridPass))

$logSheetId = Read-Host "Google Sheets ID"

Write-Host "`nGoogle Service Account JSON:"
Write-Host "(Paste the complete JSON content from your service account file)" -ForegroundColor Gray
$serviceAccountJson = Read-Host

# Optional ESO SFTP
Write-Host "`n--- Optional ESO SFTP ---" -ForegroundColor Yellow
$setupSftp = Read-Host "Configure ESO SFTP integration? (y/n)"

# Set core secrets
Write-Host "`nConfiguring secrets..." -ForegroundColor Blue

flyctl secrets set RESGRID_USER="$resgridUser" --app $AppName
if ($LASTEXITCODE -ne 0) { Write-Host "Failed to set RESGRID_USER" -ForegroundColor Red; exit 1 }

flyctl secrets set RESGRID_PASS="$resgridPassPlain" --app $AppName
if ($LASTEXITCODE -ne 0) { Write-Host "Failed to set RESGRID_PASS" -ForegroundColor Red; exit 1 }

flyctl secrets set LOG_SHEET_ID="$logSheetId" --app $AppName
if ($LASTEXITCODE -ne 0) { Write-Host "Failed to set LOG_SHEET_ID" -ForegroundColor Red; exit 1 }

flyctl secrets set GOOGLE_SERVICE_ACCOUNT_JSON="$serviceAccountJson" --app $AppName
if ($LASTEXITCODE -ne 0) { Write-Host "Failed to set GOOGLE_SERVICE_ACCOUNT_JSON" -ForegroundColor Red; exit 1 }

# Optional SFTP configuration
if ($setupSftp -eq "y" -or $setupSftp -eq "Y") {
    Write-Host "`nConfiguring ESO SFTP..." -ForegroundColor Blue
    
    $sftpHost = Read-Host "SFTP Host (e.g., sftp.esosuite.net)"
    $sftpUser = Read-Host "SFTP Username"
    $sftpPass = Read-Host "SFTP Password" -AsSecureString
    $sftpPassPlain = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($sftpPass))
    $sftpDir = Read-Host "SFTP Directory Path"
    
    flyctl secrets set SFTP_HOST="$sftpHost" --app $AppName
    flyctl secrets set SFTP_USER="$sftpUser" --app $AppName
    flyctl secrets set SFTP_PASS="$sftpPassPlain" --app $AppName
    flyctl secrets set SFTP_DIR="$sftpDir" --app $AppName
    
    Write-Host "✓ ESO SFTP configured" -ForegroundColor Green
}

Write-Host "`n✓ All secrets configured successfully" -ForegroundColor Green

# Restart application to pick up new secrets
Write-Host "`nRestarting application..." -ForegroundColor Blue
flyctl apps restart $AppName

Write-Host "`n========================================" -ForegroundColor Green
Write-Host "SECRETS CONFIGURATION COMPLETE" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green

Write-Host "Application restarted with new configuration" -ForegroundColor Cyan
Write-Host "Monitor logs: flyctl logs --app $AppName" -ForegroundColor Gray