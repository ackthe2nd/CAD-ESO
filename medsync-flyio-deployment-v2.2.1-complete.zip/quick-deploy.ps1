# MEDsync EMS Suite - Quick Deploy with Pre-configured Secrets
# One-click deployment with your actual production credentials

param(
    [string]$AppName = "medsync-ems-bridge"
)

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "MEDsync EMS Suite - Quick Deploy" -ForegroundColor Cyan
Write-Host "Production credentials pre-configured" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

# Pre-configured production secrets
$RESGRID_USER = "EMSadmin"
$RESGRID_PASS = "a1b2c3D*"
$SFTP_HOST = "sftp.esosuite.net"
$SFTP_USER = "CA-EMS"
$SFTP_PASS = "EventMedicalPCR1!"
$SFTP_DIR = "/CA-EMS/b394de98-a5b7-408d-a1f2-020eddff92b9"

Write-Host "Using pre-configured production credentials..." -ForegroundColor Green
Write-Host "App Name: $AppName" -ForegroundColor Yellow

# Only need Google Sheets configuration
Write-Host "`n--- Google Sheets Configuration Required ---" -ForegroundColor Magenta
$logSheetId = Read-Host "Enter Google Sheets ID"
Write-Host "Paste Google Service Account JSON (complete JSON):"
$serviceAccountJson = Read-Host

# Check flyctl
try {
    flyctl version | Out-Null
    Write-Host "✓ Fly.io CLI ready" -ForegroundColor Green
} catch {
    Write-Host "✗ Install Fly.io CLI first: https://fly.io/docs/hands-on/install-flyctl/" -ForegroundColor Red
    exit 1
}

# Create or verify app
Write-Host "`nSetting up Fly.io app..." -ForegroundColor Blue
try {
    flyctl apps show $AppName 2>$null | Out-Null
    Write-Host "✓ App '$AppName' found" -ForegroundColor Green
} catch {
    Write-Host "Creating app '$AppName'..." -ForegroundColor Yellow
    flyctl apps create $AppName
    Write-Host "✓ App created" -ForegroundColor Green
}

# Deploy application
Write-Host "`nDeploying application..." -ForegroundColor Blue
flyctl deploy --app $AppName --dockerfile Dockerfile

if ($LASTEXITCODE -ne 0) {
    Write-Host "✗ Deployment failed" -ForegroundColor Red
    exit 1
}

# Configure all secrets at once
Write-Host "`nConfiguring production secrets..." -ForegroundColor Blue

$secrets = @(
    "RESGRID_USER=$RESGRID_USER",
    "RESGRID_PASS=$RESGRID_PASS",
    "SFTP_HOST=$SFTP_HOST",
    "SFTP_USER=$SFTP_USER", 
    "SFTP_PASS=$SFTP_PASS",
    "SFTP_DIR=$SFTP_DIR",
    "LOG_SHEET_ID=$logSheetId",
    "GOOGLE_SERVICE_ACCOUNT_JSON=$serviceAccountJson"
)

foreach ($secret in $secrets) {
    flyctl secrets set $secret --app $AppName
}

# Scale and start
Write-Host "`nStarting service..." -ForegroundColor Blue
flyctl scale count 1 --app $AppName

$appUrl = "https://$AppName.fly.dev"

Write-Host "`n========================================" -ForegroundColor Green
Write-Host "DEPLOYMENT COMPLETE" -ForegroundColor Green  
Write-Host "========================================" -ForegroundColor Green
Write-Host "Emergency Service Integration: ACTIVE" -ForegroundColor Red -BackgroundColor Yellow
Write-Host "Application URL: $appUrl" -ForegroundColor Cyan
Write-Host "Health Check: $appUrl/status" -ForegroundColor Cyan
Write-Host "XML Integrity: $appUrl/integrity" -ForegroundColor Cyan

Write-Host "`nMonitor: flyctl logs --app $AppName" -ForegroundColor Gray
Write-Host "Status: flyctl status --app $AppName" -ForegroundColor Gray