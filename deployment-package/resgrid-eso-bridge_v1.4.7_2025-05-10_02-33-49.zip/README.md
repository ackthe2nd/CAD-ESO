# Resgrid to ESO Bridge (v1.4.7)

## Overview
This application connects to the Resgrid API, listens for new emergency calls, and forwards them to ESO as XML files via SFTP.

## New in Version 1.4.7
- Enhanced XML upload logging to Google Sheets
- Added Status and XML content columns to the Logs sheet
- Improved unit name handling in XML output
- Better error tracking for failed uploads

## Configuration
Copy `.env.example` to `.env` and configure the following:

```
# Resgrid API credentials
RESGRID_USER=your_username
RESGRID_PASS=your_password

# ESO SFTP credentials
SFTP_HOST=sftp.esosuite.net
SFTP_PORT=22
SFTP_USER=your_sftp_username
SFTP_PASS=your_sftp_password
SFTP_DIR=/incoming

# Google Sheets integration (optional)
GOOGLE_SERVICE_ACCOUNT_JSON={"your_service_account_json_here"}
LOG_SHEET_ID=your_google_sheet_id
```

## Running the Application
1. Install dependencies: `npm install`
2. Configure environment variables in `.env`
3. Start the service: `node listener.js`

## Support
For questions or support, refer to the deployment documentation or contact the developer.
