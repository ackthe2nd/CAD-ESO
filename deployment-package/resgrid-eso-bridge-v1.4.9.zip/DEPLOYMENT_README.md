# Resgrid-ESO Bridge v1.4.9 Deployment Package

This package contains the Resgrid-ESO Bridge application with the following enhancements:

## Key Updates in v1.4.9

- Fixed Google Sheets integration to support nested data structure in API responses
- Enhanced unit name extraction from Activity array and dispatch notes
- Improved extraction of status timestamps from various sources
- Added detailed documentation about the nested data structure

## Installation

1. Extract all files to your deployment directory
2. Copy `.env.example` to `.env` and configure your environment variables
3. Install dependencies with `npm install`
4. Start the bridge with `node listener.js`

See VERSION_SUMMARY_V1.4.9.md for complete release notes.

Created: 2025-05-10T03:00:23.577Z
