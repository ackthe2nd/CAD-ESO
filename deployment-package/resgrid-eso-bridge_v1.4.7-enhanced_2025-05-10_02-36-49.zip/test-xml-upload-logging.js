/**
 * Test script to verify XML upload logging to Google Sheets
 * This script simulates an XML upload and logs the status and content to Google Sheets
 */
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { sheetLog } = require('./src/sheets-logger');
const logger = require('./src/fix-logger');

// Sample XML content
const sampleXML = `<?xml version="1.0" encoding="UTF-8"?>
<CadIncident xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <IncidentNumber>TEST-123</IncidentNumber>
  <IncidentOrOnset>2025-05-10T03:00:00Z</IncidentOrOnset>
  <DispatchNotified>2025-05-10T03:00:00Z</DispatchNotified>
  <IncidentAddress1>123 Test Street</IncidentAddress1>
  <IncidentCity>Testville</IncidentCity>
  <IncidentState>TS</IncidentState>
  <IncidentZip>12345</IncidentZip>
  <CadDispatchText>Test XML upload logging</CadDispatchText>
  <EmsUnitCallSign>STN1,BLS11</EmsUnitCallSign>
  <UnitNotifiedByDispatch>STN1,BLS11</UnitNotifiedByDispatch>
  <ResponseModeToScene>390</ResponseModeToScene>
  <CallNature>Test Call</CallNature>
  <CallNatureDescription>This is a test call to verify XML logging</CallNatureDescription>
</CadIncident>`;

async function testSuccessfulUpload() {
  try {
    logger.info('Testing successful XML upload logging...');
    
    // Log XML content with success status
    await sheetLog('XML file uploaded to ESO: test_call_123.xml', 'info', 'Success', sampleXML);
    
    logger.info('✅ Successfully logged successful XML upload to Google Sheets');
    return true;
  } catch (error) {
    logger.error(`❌ Error testing successful upload logging: ${error.message}`);
    return false;
  }
}

async function testFailedUpload() {
  try {
    logger.info('Testing failed XML upload logging...');
    
    // Log XML content with failed status
    await sheetLog('Failed to upload XML file to ESO: test_call_123.xml', 'error', 'Failed', sampleXML);
    
    logger.info('✅ Successfully logged failed XML upload to Google Sheets');
    return true;
  } catch (error) {
    logger.error(`❌ Error testing failed upload logging: ${error.message}`);
    return false;
  }
}

async function main() {
  try {
    logger.info('Starting XML upload logging test...');
    
    // Test successful upload logging
    const successTest = await testSuccessfulUpload();
    
    // Test failed upload logging
    const failedTest = await testFailedUpload();
    
    if (successTest && failedTest) {
      logger.info('✅ All XML upload logging tests passed!');
    } else {
      logger.error('❌ Some XML upload logging tests failed');
    }
  } catch (error) {
    logger.error(`❌ Error running tests: ${error.message}`);
  }
}

// Run the tests
main();