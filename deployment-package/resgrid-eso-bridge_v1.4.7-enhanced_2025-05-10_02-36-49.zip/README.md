# Resgrid to ESO Bridge (v1.4.7 Enhanced)

## Overview
This application connects to the Resgrid API, listens for new emergency calls, and forwards them to ESO as XML files via SFTP.

## New in Version 1.4.7 Enhanced
- Enhanced XML upload logging to Google Sheets with detailed status information
- Added Status and XML content columns to the Logs sheet for better tracking
- Improved error reporting with specific failure reasons and Call ID tracking
- Enhanced unit name handling in XML output
- Includes test scripts for verifying XML logging functionality

## Configuration
Copy `.env.example` to `.env` and configure the following:

```
# Resgrid API credentials
RESGRID_USER=your_username
RESGRID_PASS=your_password

# ESO SFTP credentials
SFTP_HOST=sftp.esosuite.net
SFTP_PORT=22
SFTP_USER=your_sftp_username
SFTP_PASS=your_sftp_password
SFTP_DIR=/incoming

# Google Sheets integration (optional)
GOOGLE_SERVICE_ACCOUNT_JSON={"your_service_account_json_here"}
LOG_SHEET_ID=your_google_sheet_id
```

## Running the Application
1. Install dependencies: `npm install`
2. Configure environment variables in `.env`
3. Start the service: `node listener.js`

## Testing XML Logging
You can verify XML logging functionality with the included test scripts:
- Basic XML logging: `node test-xml-upload-logging.js`
- XML size handling: `node test-xml-size-handling.js`

## Support
For questions or support, refer to the deployment documentation or contact the developer.
