#!/bin/bash

# Resgrid-ESO Bridge v2.2.0 - Production Deployment
# Run this script to deploy to Fly.io

set -e

echo "Deploying Resgrid-ESO Bridge v2.2.0..."

# Check prerequisites
if ! command -v flyctl &> /dev/null; then
    echo "Installing Fly CLI..."
    curl -L https://fly.io/install.sh | sh
    export PATH="$HOME/.fly/bin:$PATH"
fi

# Authenticate if needed
if ! flyctl auth whoami &> /dev/null; then
    echo "Please authenticate with Fly.io:"
    flyctl auth login
fi

# Create app if it doesn't exist
if ! flyctl apps list | grep -q "resgrid2eso"; then
    echo "Creating Fly.io app..."
    flyctl apps create resgrid2eso --region lax
fi

# Deploy
echo "Deploying application..."
flyctl deploy --app resgrid2eso --strategy rolling

# Set secrets (run this manually with your actual values)
echo ""
echo "Next step: Set your secrets with this command:"
echo ""
echo "flyctl secrets set \\"
echo "  RESGRID_USER=\"your_username\" \\"
echo "  RESGRID_PASS=\"your_password\" \\"
echo "  SFTP_PASS=\"your_eso_password\" \\"
echo "  GOOGLE_SERVICE_ACCOUNT_JSON='{\"type\":\"service_account\",...}' \\"
echo "  LOG_SHEET_ID=\"your_sheets_id\" \\"
echo "  --app resgrid2eso"
echo ""
echo "Then verify deployment: curl https://resgrid2eso.fly.dev/status"