# PowerShell script to export calls to Google Sheets through Fly.io
# Usage:
#   ./export-calls-to-sheets.ps1 [-Active] [-Days <number>]
#
# Parameters:
#   -Active  : Export only active calls (default: false)
#   -Days    : Look back N days for recent calls (default: 7, ignored if -Active is used)
#
# Example:
#   ./export-calls-to-sheets.ps1                # Export calls from last 7 days
#   ./export-calls-to-sheets.ps1 -Active        # Export only active calls
#   ./export-calls-to-sheets.ps1 -Days 30       # Export calls from last 30 days

param (
    [switch]$Active,
    [int]$Days = 7
)

# Set up the command arguments
$arguments = ""
if ($Active) {
    $arguments = "--active"
} else {
    $arguments = "--days=$Days"
}

# Print information about what we're doing
Write-Host "Exporting Resgrid calls to Google Sheets through Fly.io..."
if ($Active) {
    Write-Host "Mode: Active calls only"
} else {
    Write-Host "Mode: Recent calls from the last $Days days"
}

# Execute the command on Fly.io
try {
    Write-Host "`nRunning command on Fly.io..."
    fly ssh console -C "node export-calls-to-sheets.js $arguments"
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "`nExport completed successfully!" -ForegroundColor Green
    } else {
        Write-Host "`nExport failed with exit code $LASTEXITCODE" -ForegroundColor Red
    }
} catch {
    Write-Host "`nError executing command on Fly.io: $_" -ForegroundColor Red
    Write-Host "`nMake sure you have the Fly CLI installed and you're logged in." -ForegroundColor Yellow
    Write-Host "Run 'fly auth login' to authenticate if needed." -ForegroundColor Yellow
}