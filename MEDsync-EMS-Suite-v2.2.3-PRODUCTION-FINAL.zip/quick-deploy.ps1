#!/usr/bin/env pwsh
# MEDsync EMS Suite v2.2.2 - Quick Deployment Script
# Automated deployment to Fly.io with pre-configured credentials

Write-Host "======================================" -ForegroundColor Green
Write-Host "MEDsync EMS Suite v2.2.2 Deployment" -ForegroundColor Green
Write-Host "======================================" -ForegroundColor Green

# Check if Fly CLI is installed
Write-Host "Checking Fly CLI installation..." -ForegroundColor Yellow
try {
    $flyVersion = fly version 2>$null
    if ($LASTEXITCODE -ne 0) {
        throw "Fly CLI not found"
    }
    Write-Host "✅ Fly CLI detected: $flyVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ Fly CLI not installed. Installing..." -ForegroundColor Red
    if ($IsWindows) {
        Invoke-WebRequest -Uri "https://fly.io/install.ps1" -UseBasicParsing | Invoke-Expression
    } else {
        curl -L https://fly.io/install.sh | sh
    }
    Write-Host "✅ Fly CLI installed successfully" -ForegroundColor Green
}

# Authenticate with Fly.io
Write-Host "`nAuthenticating with Fly.io..." -ForegroundColor Yellow
fly auth login

# Deploy the application
Write-Host "`nDeploying MEDsync EMS Suite..." -ForegroundColor Yellow
fly deploy --ha=false

# Configure all production secrets
Write-Host "`nConfiguring production secrets..." -ForegroundColor Yellow

$secrets = @{
    "RESGRID_USER" = "EMSadmin"
    "RESGRID_PASS" = "a1b2c3D*"
    "SFTP_HOST" = "sftp.esosuite.net"
    "SFTP_USER" = "CA-EMS"
    "SFTP_PASS" = "EventMedicalPCR1!"
    "SFTP_REMOTE_PATH" = "/CA-EMS/b394de98-a5b7-408d-a1f2-020eddff92b9"
    "GOOGLE_SERVICE_ACCOUNT_JSON" = '{"type":"service_account","project_id":"ca-ems-data-integration","private_key_id":"abc123def456","private_key":"-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC...\n-----END PRIVATE KEY-----\n","client_email":"medsync@ca-ems-data-integration.iam.gserviceaccount.com","client_id":"123456789012345678901","auth_uri":"https://accounts.google.com/o/oauth2/auth","token_uri":"https://oauth2.googleapis.com/token","auth_provider_x509_cert_url":"https://www.googleapis.com/oauth2/v1/certs","client_x509_cert_url":"https://www.googleapis.com/robot/v1/metadata/x509/medsync%40ca-ems-data-integration.iam.gserviceaccount.com","universe_domain":"googleapis.com"}'
    "LOG_SHEET_ID" = "1BcY8tVZ9k2cDe7XhGpMqR4nKwLvJsF8uT3oA6iY9qE"
}

foreach ($secret in $secrets.GetEnumerator()) {
    Write-Host "Setting $($secret.Key)..." -ForegroundColor Cyan
    fly secrets set "$($secret.Key)=$($secret.Value)"
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✅ $($secret.Key) configured" -ForegroundColor Green
    } else {
        Write-Host "❌ Failed to set $($secret.Key)" -ForegroundColor Red
        exit 1
    }
}

# Wait for deployment to complete
Write-Host "`nWaiting for deployment to stabilize..." -ForegroundColor Yellow
Start-Sleep -Seconds 30

# Verify deployment
Write-Host "`nVerifying deployment..." -ForegroundColor Yellow
try {
    $appUrl = "https://resgrid2eso.fly.dev"
    $healthResponse = Invoke-RestMethod -Uri "$appUrl/status" -Method Get -TimeoutSec 30
    
    if ($healthResponse.status -eq "OK") {
        Write-Host "✅ Deployment successful!" -ForegroundColor Green
        Write-Host "✅ Service URL: $appUrl" -ForegroundColor Green
        Write-Host "✅ Health Check: $appUrl/status" -ForegroundColor Green
        
        # Display component status
        Write-Host "`n=== Component Health ===" -ForegroundColor Yellow
        Write-Host "Resgrid Connection: $($healthResponse.resgrid_connection.status)" -ForegroundColor Cyan
        Write-Host "Google Sheets: $($healthResponse.google_sheets_connection.status)" -ForegroundColor Cyan
        Write-Host "XML Integrity: $($healthResponse.xml_integrity_monitor.status)" -ForegroundColor Cyan
        Write-Host "SFTP Config: $($healthResponse.sftp_configuration.status)" -ForegroundColor Cyan
        
    } else {
        Write-Host "⚠️ Deployment completed but health check shows issues" -ForegroundColor Yellow
        Write-Host "Status: $($healthResponse.status)" -ForegroundColor Yellow
    }
} catch {
    Write-Host "❌ Health check failed: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "The application may still be starting up. Check logs with: fly logs" -ForegroundColor Yellow
}

# Show useful commands
Write-Host "`n=== Useful Commands ===" -ForegroundColor Yellow
Write-Host "View logs: fly logs" -ForegroundColor Cyan
Write-Host "Check status: fly status" -ForegroundColor Cyan
Write-Host "Scale app: fly scale count 1" -ForegroundColor Cyan
Write-Host "SSH access: fly ssh console" -ForegroundColor Cyan
Write-Host "Monitor: fly dashboard" -ForegroundColor Cyan

Write-Host "`n======================================" -ForegroundColor Green
Write-Host "MEDsync EMS Suite v2.2.2 Deployed!" -ForegroundColor Green
Write-Host "======================================" -ForegroundColor Green