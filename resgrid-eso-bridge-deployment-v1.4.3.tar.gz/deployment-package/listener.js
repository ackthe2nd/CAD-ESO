/**
 * Resgrid to ESO Bridge Application
 * Enhanced version with token refresh logic and structured logging
 * 
 * This file is a simplified entry point that loads the main application.
 */
require('./src/index');