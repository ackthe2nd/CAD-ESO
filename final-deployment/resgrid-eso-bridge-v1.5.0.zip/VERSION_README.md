# Resgrid to ESO Bridge v1.5.0
  
This package contains the Resgrid to ESO Bridge application, version 1.5.0.

## What's New in This Version

This update focuses on ensuring consistent XML generation across all parts of the system:

- Enhanced GPS coordinate extraction from unit activity data
- Fixed issues with key timestamp fields sometimes being empty
- Improved handling of nested data structures in API responses
- Fixed discrepancies between XML saved to logs and XML uploaded to SFTP

For complete details, see VERSION_SUMMARY_V1.5.0.md in this package.

## Installation

1. Extract all files from this zip package
2. Copy your existing .env file or create a new one using .env.example as a template
3. Install dependencies with `npm install`
4. Start the application with `node src/index.js`

## Deployment

For deployment to Fly.io, follow the instructions in DEPLOYING_TO_FLY_IO.md.

## Documentation

- FIELD_MAPPING_REFERENCE.md - Details about field mappings from Resgrid to ESO
- UNIT_STATUS_GUIDE.md - Information about unit status codes and handling
- GOOGLE_SHEETS_EXPORT.md - Guide for setting up and using Google Sheets integration
- XML_CONSISTENCY_FIX.md - Technical details about the XML consistency fixes

## Support

For support, please contact the development team.

## Version History

- v1.5.0 - XML Consistency Fixes
- v1.4.9 - Google Sheets Nested Data Structure Fixes
- v1.4.8 - Google Sheets Integration Fixes
- v1.4.7 - Enhanced Logging Features
- v1.4.6 - XML Field Updates
- v1.4.5 - Token Refresh Optimization
- v1.4.4 - API Endpoint Fixes
- v1.4.3 - SFTP Upload Enhancements
- v1.4.2 - Call Data Processing Improvements
- v1.4.1 - SignalR Connection Stability
- v1.4.0 - Initial Release with Google Sheets Integration
